Archivos incluidos:
- icon-192.png
- icon-512.png
- apple-touch-icon.png
- favicon-32.png
- favicon-16.png
- manifest.json

Ponelos en:
static/icons/

En el <head> de tu HTML agrega:
<link rel="apple-touch-icon" href="{{ url_for('static', filename='icons/apple-touch-icon.png') }}">
<link rel="manifest" href="{{ url_for('static', filename='icons/manifest.json') }}">
<meta name="theme-color" content="#0f0f10">

Si iPhone sigue mostrando el icono viejo:
1. Borrá el acceso directo de la pantalla de inicio
2. Abrí Safari en tu web
3. Compartir > Añadir a pantalla de inicio
